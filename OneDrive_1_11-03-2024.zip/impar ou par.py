num= int(input('digite o número inteiro'))
if(num %2!=1):
    print (f'ele é um número par')
else:
    print (f'ele é um número ímpar')