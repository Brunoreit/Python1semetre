#Este programa verifica se um número lido é ímpar caso não seja ele é transformado em ímpar

num=int(input('digite um  número '))
if (num %2==0):
    num= num+1
print(f' o valor transformado em ímpar é {num}') 