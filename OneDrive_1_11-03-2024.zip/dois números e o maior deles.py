primeiro_num= int(input('digite o primeiro número'))
segunddo_num=int(input('digite o segundo número'))

if (primeiro_num>segunddo_num):
    print(f'valor de {primeiro_num} é maior')
else:
    print(f'valor de {segunddo_num} é maior')