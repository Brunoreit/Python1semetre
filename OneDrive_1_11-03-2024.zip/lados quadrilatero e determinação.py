base=int(input('digite o lado '))
altura=int(input('digite a altura'))
if(base==altura):
    print(f'o quadrilátero é um quadrado')
else:
    print(f'o quadrilátero é um retângulo')

