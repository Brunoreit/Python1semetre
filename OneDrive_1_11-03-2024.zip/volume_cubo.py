aresta= int(input('digite o valor da aresta do cubo'))

V= {aresta**3}

print(f'O volume do cubo de aresta {aresta} é {V}')