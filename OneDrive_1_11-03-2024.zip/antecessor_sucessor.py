num= int(input("digite um número"))
antece = num-1
suce = num+1
print (f" o antecessor de {num} é {antece}")
print (f" o sucessor de {num} é {suce}")