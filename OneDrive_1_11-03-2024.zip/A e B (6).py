A=int(input("digite o valor de A"))
B=int(input("digite o valor de B"))

if (A==B):
    C=A+B
else:
    C=A*B
print(f"o valor do resultado é {C}") 
