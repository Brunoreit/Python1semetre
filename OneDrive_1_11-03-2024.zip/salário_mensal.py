salario = float(input("digite o salário"))

percentual_reajuste = float(input("digite o percentural de reajuste"))

salario_reajustado = salario + (salario * percentual_reajuste/100)

print (f'O salário com reajuste é {salario_reajustado}')