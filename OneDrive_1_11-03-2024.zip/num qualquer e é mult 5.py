num=int(input('digite o valor'))
if(num%5 ==0 and 5 ):
    print(f'o {num} é divisivel por 5')
else:
    print(f'o {num} não é divisivel por 5')
