distancia= float (input("Digite a distância percorrida em Km"))
combustivel= float(input('digite o total de combustivel gasto'))
consumo= distancia/combustivel
print (f"o consumo médio foi de: {consumo}km/l ")