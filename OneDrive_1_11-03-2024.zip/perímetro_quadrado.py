L= int(input('Digite o número do lado do quadrado'))
P=L*4
print(f'perímetro do quadrado de lado {L} é {P} ')