num= int(input('digite o valor'))

if (num==0):
    print('o valor é nulo')
if (num>0):
    print('o valor é positivo')
if(num<0): 
    print('o valor é negativo')