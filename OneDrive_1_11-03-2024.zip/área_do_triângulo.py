altura = int(input('Digite a altura do triãngulo: '))
base = int(input('Digite a base do triãngulo: '))
area = (base * altura)/2
print(f'A área do triangulo é {area}')